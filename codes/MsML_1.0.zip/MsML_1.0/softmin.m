function acc = softmin(tX,tY,X,Y,sigma)

%input:
%tX: test data
%tY: test label
%X: reference data
%Y: reference label
%sigma: the parameter in softmin

%output:
%acc: accuracy of prediction

classnum = max(Y);
dist = repmat(sum(tX.^2,1),length(Y),1)+repmat(sum(X.^2,1)',1,length(tY)) - 2.*X'*tX;
dist = sqrt(dist);
acc = 0;
for i=1:length(tY)
    distcate = zeros(classnum,1);
    if sigma==0
        for j=1:classnum
            distcate(j) = min(dist(Y==j,i));
        end
    else
        refdis = dist(:,i);
        offset = min(refdis);
        expdist = exp(-sigma.*(refdis - offset));
        for j=1:classnum
            distcate(j) = sum(expdist(Y==j));
        end
        distcate = -log(distcate)./sigma+offset;
    end
    curd = distcate(tY(i));
    index = sum(distcate<=curd);
    if index<=1
        acc = acc+1;
    end
end
acc = acc/length(tY);