function alpha = primal2dual(X1,X2,trips,gamma,M)

%input:
%X1: m*n dataset after random projection
%X2: m*n dataset after random projection
%trips: index of triplet constraints in the current stage
%gamma: the parameter in the smoothed hinge loss
%M: m*m metric learned in the current stage

%output:
%alpha: the dual variables corresponding to the triplet constraints

T = size(trips,1);
alpha = zeros(T,1);

for t=1:T
    Xij = (X1(:,trips(t,1)) - X1(:,trips(t,2)))*(X2(:,trips(t,1)) - X2(:,trips(t,2)))';
    Xik = (X1(:,trips(t,1)) - X1(:,trips(t,3)))*(X2(:,trips(t,1)) - X2(:,trips(t,3)))';
    At = Xik-Xij;
    alpha(t) = grad(sum(dot(At,M)),gamma);
end

