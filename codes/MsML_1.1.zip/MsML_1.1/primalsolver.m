function averM = primalsolver(X1,X2,trips,gamma,pM,flag)

%input:
%X1: m*n dataset after random projection
%X2: m*n dataset after random projection
%trips: index of triplet constraints in the current stage
%gamma: the parameter in the smoothed hinge loss
%pM: m*m learned metric from the previous stage
%flag: indicate if it is the first stage

%output:
%averM: m*m metric learned by SGD in the current stage

rng('shuffle','twister');
T = size(trips,1);
sele = randperm(T);
M = pM;
averM = zeros(size(M));
lamdba = 1/T;
for iter=1:T
    eta = 1/iter;
    coeff = eta*lamdba;
    cur = sele(iter);
    Xij = (X1(:,trips(cur,1)) - X1(:,trips(cur,2)))*(X2(:,trips(cur,1)) - X2(:,trips(cur,2)))';
    Xik = (X1(:,trips(cur,1)) - X1(:,trips(cur,3)))*(X2(:,trips(cur,1)) - X2(:,trips(cur,3)))';
    At = Xik-Xij;
    hinge = sum(dot(At,M));
    M = (1-coeff).*M;
    if flag
       M = M+coeff.*pM;
    end
    if hinge<=1
       G = grad(hinge,gamma);
       M = M - (eta*G).*At;
    end
    averM = averM+M;
end
averM = averM./T;
        
    
    
    