function trips = NNsample(X,Y,near,margin)

%input:
%X: r*n dataset
%Y: n*1 label
%near: the range of the neighborhood for sampling triplets
%margin: the margin for sampling triplets

%output:
%trips: index of one epoch active triplet constraints

ins = length(Y);
trips = zeros(ins,3);
tnorm = sum(X.^2,1);
count=0;
dist = repmat(tnorm',1,ins) - 2.*X'*X;
for cur=1:ins
    dis = dist(:,cur);
    dis(cur) = inf;
    indnn = find(Y==Y(cur));
    [~,ind] = sort(dis(indnn));
    sele = min(near,length(indnn)-1);
    indnn = indnn(ind(1:sele));
    neg = find((dis<=dis(indnn(end)))&(Y~=Y(cur)));
    if ~isempty(neg)
        nindex = neg(randi(length(neg)));
        pp = find(dis(indnn)>=dis(nindex)-margin,1,'first');
        if pp>0
            count = count+1;
            indnn = indnn(pp:end);            
            trips(count,1) = cur;
            trips(count,2) = indnn(randi(length(indnn)));
            trips(count,3) = nindex;
        end
    end
end
trips = trips(1:count,:);