function triplets = randomsample(Y)

%input: 
%Y: n*1 label

%output:
%triplets: index of randomply sampled one epoch triplet constraints

ins = length(Y);
classnum = max(Y);
triplets = zeros(ins,3);
cur=0;
for i=1:classnum
    inclass = find(Y==i);
    exclass = find(Y~=i);
    innum = length(inclass);
    triplets(cur+1:cur+innum,:) = [inclass,inclass(randi(innum,innum,1)),exclass(randi(ins-innum,innum,1))];
    cur = cur+innum;
end