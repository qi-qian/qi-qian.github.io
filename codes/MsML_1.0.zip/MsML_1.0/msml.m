function L = msml(X,Y,paras)

%The implementation of the method in "Fine-Grained Visual Categorization
%via Multi-Stage Metric Learning", CVPR 2015

%input:
%X: d*n dataset
%Y: n*1 label
%paras: input parameters
%paras.epochs: number of total iterations
%paras.mdim: number of random projections for dual random projection method.
%            Usually, keeping 1% dimensions is sufficient, e.g., 100 for
%            10,000 features
%paras.qdim: number of random projections for randomized
%            eigen-decomposition method. The number should be a
%            little more than twice of the learned metric's rank
%paras.near: the range of the neighborhood for sampling triplets
%paras.margin: the margin for sampling triplets
%paras.gamma: the parameter in the smoothed hinge loss


%output:
%L: r*d matrix and learned metric M=L'*L

%Version 1.0
%copyright 2015 @ Qi Qian
%If you have any question, please contact qianqi@cse.msu.edu


rng('shuffle','twister');
if ~isfield(paras, 'epochs')
    paras.epochs = 50;
end
if ~isfield(paras, 'mdim')
    paras.mdim = 100;
end
if ~isfield(paras, 'qdim')
    paras.qdim = 600;
end
if ~isfield(paras, 'near')
    paras.near = 50;
end
if ~isfield(paras, 'gamma')
    paras.gamma = 1;
end
if ~isfield(paras, 'margin')
    paras.margin = 0.01;
end

tic;
[dim,ins] = size(X);

dX1 = (randn(paras.mdim,dim)./sqrt(paras.mdim))*X;
dX2 = (randn(paras.mdim,dim)./sqrt(paras.mdim))*X;
A = randn(paras.qdim,dim)*X;
C = sparse(ins,ins);
iniM = eye(paras.mdim);
trips = randomsample(Y);
bA = zeros(paras.qdim,ins);
M = primalsolver(dX1,dX2,trips,paras.gamma,iniM,0);
alpha = primal2dual(dX1,dX2,trips,paras.gamma,M);
[L,~,~] = recover(A,alpha,trips,X,C,bA);
M = iniM;
pre_t=toc;
tic;
for iter = 1:paras.epochs
    fprintf('iter %d--------------------\n', iter)
    t1 = toc;
    trips = NNsample(L*X,Y,paras.near,paras.margin);
    t2 = toc;
    fprintf('Sampling time is %.4f\n', t2-t1);
    M = primalsolver(dX1,dX2,trips,paras.gamma,M,iter>1);
    alpha = primal2dual(dX1,dX2,trips,paras.gamma,M);
    [L,C,bA] = recover(A,alpha,trips,X,C,bA);
    t3 = toc;
    fprintf('Training time is %.4f\n',t3-t2);
    fprintf('total time is %.4f\n',toc+pre_t)
end


