function [L,C,bA] = recover(A,alpha,trips,X,C,bA)

%input:
%A: p*n dataset after random projection
%alpha: dual variables corresponding to the triplet constraints
%trips: index of triplet constraints in the current stage
%X: d*n original dataset
%C: accumulated dual variables
%bA: p*n accumulated dataset for randomized eigen-decomposition

%output:
%L: the low rank part of the learned metric
%C: accumulated dual variables
%bA: p*n accumulated dataset for randomized eigen-decomposition

newC = dual2matrix(alpha,trips,size(X,2));
bA = bA+A*newC;
C = C+newC;
A = bA*X';

[Q,~] = qr(A',0);
A = Q'*X;
A = A*(C*A');
[V,D] = eig((A+A')./2);
d = diag(D);
L = V(:,d>0)*diag(sqrt(d(d>0)));
L = Q*L;
L = L';
