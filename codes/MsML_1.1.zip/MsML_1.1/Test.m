load isolet;%an UCI dataset

%Set parameters for training
paras.epochs = 10;
paras.mdim = 10;
paras.qdim = 300;
paras.near = 50;
paras.gamma = 1;
paras.margin = 0.01;
paras.sample = false;

%Set parameters for test
ref_num=10;
sigma=[0,10,20];

%Baseline of Euclidean
fprintf('Baseline: Euclidean distance\n');
predict(X,Y,tX,tY,ref_num,sigma); 

%Learn the low rank metric with one epoch triplets at each iteration
fprintf('MsML: One epoch triplets per iteration\n');
L = msml(X,Y,paras);
%Prediction by smoothed k-NN, which is more efficient for large-scale
%dataset, with the learned metric
predict(L*X,Y,L*tX,tY,ref_num,sigma);

%Learn the low rank metric with sampled triplets for efficiency
fprintf('MsML: Sampled triplets per iteraion\n');
paras.sample = true;
paras.ssize = 3000;
L = msml(X,Y,paras);
predict(L*X,Y,L*tX,tY,ref_num,sigma);