function acc = predict(X,Y,tX,tY,refnum,sigma)

%input: 
%X: d*n training dataset
%Y: n*1 training label
%tX: d*n test dataset
%tY: n*1 test label
%refnum: number of reference examples (i.e., clusters) for each class
%sigma: the paramters in softmin,e.g., [0,10,20]

%output:
%acc: accuracy with different sigma

%The smoothed k-NN is more efficient than standard k-NN when certain
%classes contain a large number of examples

if isempty(refnum)
    refnum=15;
end
refdata = [];
reflabel = [];
acc = zeros(length(sigma),1);
for i=1:max(Y)
    data = X(:,Y==i);
    if size(data,2)<=refnum
        refdata = [refdata,data];     
        reflabel = [reflabel;ones(size(data,2),1).*i];
    else
        [~,C] = kmeans(data',refnum,'emptyaction','singleton','replicates',10);
        refdata = [refdata,C'];  
        reflabel = [reflabel;ones(refnum,1).*i]; 
    end
   
end
for i=1:length(sigma)
acc(i) = softmin(tX,tY,refdata,reflabel,sigma(i));
fprintf('accuracy of %d-softmin is %.2f\n',sigma(i),acc(i)*100);
end

