function C = dual2matrix(alpha,trips,ins)

%input:
%alpha: dual variables corresponding to the triplet constraints
%trips: index of triplet constraints in the current stage
%ins: number of examples

%output:
%C: dual variables in matrix

m = find(alpha);
row = zeros(6*length(m),1);
col = zeros(6*length(m),1);
val = zeros(6*length(m),1);
index = 0;
for i=1:length(m)
    ii = trips(m(i),1);
    jj = trips(m(i),2);
    kk = trips(m(i),3);
    v = alpha(m(i));
    row(index+1:index+6) = [jj;jj;ii;ii;kk;kk];
    col(index+1:index+6) = [jj;ii;jj;kk;kk;ii];
    val(index+1:index+6) = [v,-v,-v,v,-v,v];
    index = index+6;
end
C = sparse(row,col,val,ins,ins);
    