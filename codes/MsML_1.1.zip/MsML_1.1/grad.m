function value = grad(v,gamma)

%input: 
%v: input for the smoothed hinge loss
%gamma: the parameter in the smoothed hinge loss

%output:
%value: gradient of the smoothed hinge loss


if v>1
    value=0;
elseif v<1-gamma
    value = -1;
else
    value = (v-1)/gamma;
end